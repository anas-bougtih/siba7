import React from 'react';
import { NavLink } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const Navbar = () => {
  const { i18n } = useTranslation();

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
  };

  return (
    <nav className="flex justify-between items-center p-4 bg-blue-500 text-white">
      <div>
        <NavLink className="mx-2" to="/">Inicio</NavLink>
        <NavLink className="mx-2" to="/about">Sobre mí</NavLink>
        <NavLink className="mx-2" to="/projects">Proyectos</NavLink>
        <NavLink className="mx-2" to="/contact">Contacto</NavLink>
      </div>
      <div>
        <button className="mx-1" onClick={() => changeLanguage('en')}>EN</button>
        <button className="mx-1" onClick={() => changeLanguage('fr')}>FR</button>
        <button className="mx-1" onClick={() => changeLanguage('de')}>DE</button>
      </div>
    </nav>
  );
};

export default Navbar;